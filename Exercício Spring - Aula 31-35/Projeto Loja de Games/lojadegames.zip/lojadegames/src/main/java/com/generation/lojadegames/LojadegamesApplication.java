package com.generation.lojadegames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojadegamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojadegamesApplication.class, args);
	}

}
